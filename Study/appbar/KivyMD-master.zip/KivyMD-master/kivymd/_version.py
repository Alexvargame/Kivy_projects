release = False
__version__ = "2.0.1.dev0"
__hash__ = "f7bde69707ac708a758a02d89f14997ee468d1ee"
__short_hash__ = "f7bde69"
__date__ = "2024-02-27"
